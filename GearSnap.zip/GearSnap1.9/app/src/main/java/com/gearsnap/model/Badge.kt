package com.gearsnap.model

data class Badge(
    val code: String,
    val label: String,
    val description: String
)