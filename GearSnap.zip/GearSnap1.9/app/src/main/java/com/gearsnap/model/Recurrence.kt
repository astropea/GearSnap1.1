package com.gearsnap.model

enum class Recurrence {
    NONE,
    DAILY,
    WEEKLY,
    MONTHLY,
}
